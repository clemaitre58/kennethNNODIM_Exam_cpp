#ifndef COFFEEMACHINE_H
#define COFFEEMACHINE_H


class CoffeeMachine
{
public:

  CoffeeMachine();
  CoffeeMachine(int water, int coffee);


private:
  int water_level;
  int coffee_level;
  static int const w
};

#endif // COFFEEMACHINE_H
