#include "coffeemachine.h"

CoffeeMachine::CoffeeMachine()
{

}
