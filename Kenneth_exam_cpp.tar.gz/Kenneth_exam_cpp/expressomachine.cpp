#include "expressomachine.h"

ExpressoMachine::ExpressoMachine()
{
setPressure_level(0);
}

ExpressoMachine::ExpressoMachine(int pressure){
  this->setPressure_level(pressure);
}

int ExpressoMachine::getPressure_level() const
{
  return pressure_level;
}

void ExpressoMachine::setPressure_level(int value)
{
  pressure_level = value;
}

int ExpressoMachine::getMax_pressure_level()
{
  return max_pressure_level;
}

void ExpressoMachine::init_pressure(){
  setPressure_level(this->getMax_pressure_level());
}

int ExpressoMachine::get_coffee(){
  return 1;
}
