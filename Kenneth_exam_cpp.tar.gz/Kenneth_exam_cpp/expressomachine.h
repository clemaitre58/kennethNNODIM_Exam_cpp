#ifndef EXPRESSOMACHINE_H
#define EXPRESSOMACHINE_H


class ExpressoMachine
{
public:
  ExpressoMachine();
};

#endif // EXPRESSOMACHINE_H